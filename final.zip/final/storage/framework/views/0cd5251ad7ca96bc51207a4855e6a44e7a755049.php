<!-- including master.balde.php file -->





<?php $__env->startSection('edit'); ?>


<h1 style="text-align:center; margin-bottom:50px; margin-top:50px; color:green">Edit Form</h1>

<div class="form-control1 container-form">
    <form action="/laravel/final/update" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
        </div>
        <div class="form-group">
            Name<input type="text" name="name"  value="<?php echo e($data->sname); ?>">
        </div>
        <div class="form-group">
            Class<input type="text" name="class"  value="<?php echo e($data->sclass); ?>">
        </div>
        <div class="form-group">
            Roll No.<input type="text" name="roll"  value="<?php echo e($data->sroll); ?>">
        </div>
        <input type="submit" class="btn-form" value="Update">
    </form>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\final\resources\views/admin/edit.blade.php ENDPATH**/ ?>