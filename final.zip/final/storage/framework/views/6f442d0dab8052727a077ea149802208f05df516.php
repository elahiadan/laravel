<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Dashboard Page</title>
    <!-- <link rel="stylesheet" href="assets/css/normalize.css"> -->
    <link href="<?php echo e(asset('public/assets/css/normalize.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('public/assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('public/assets/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('public/assets/css/themify-icons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('public/assets/css/pe-icon-7-filled.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('public/assets/css/flag-icon.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('public/assets/css/cs-skin-elastic.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('public/assets/css/style.css')); ?>" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
</head>

<body>
    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">
            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="menu-title">Menu</li>
                    <li class="menu-item-has-children dropdown">
                        <a href="<?php echo e(url('dashboard')); ?>">Dashboard</a>
                    </li>
                    <li class="menu-item-has-children dropdown">
                        <a href="<?php echo e(url('product')); ?>">Products</a>
                    </li>
                    <li class="menu-item-has-children dropdown">
                        <a href="<?php echo e(url('category')); ?>">Categories</a>
                    </li>
                    <li class="menu-item-has-children dropdown">
                        <a href="<?php echo e(url('product')); ?>">Customers</a>
                    </li>
                    <li class="menu-item-has-children dropdown">
                        <a href="<?php echo e(url('dashboard')); ?>">Reports</a>
                    </li>
                    <li class="menu-item-has-children dropdown">
                        <a href="<?php echo e(url('adminuser')); ?>">Users List</a>
                    </li>
                </ul>
            </div>
        </nav>
    </aside>
    <div id="right-panel" class="right-panel">
        <header id="header" class="header">
            <div class="top-left">
                <div class="navbar-header">
                    <a class="navbar-brand" href="http://localhost/laravel/three/dashboard">Matchless@Dashboard</a>
                    <a class="navbar-brand hidden" href="index.html"><img src="images/logo2.png" alt="Logo"></a>
                    <a id="menuToggle" class="menutoggle"><i class="fa fa-bars"></i></a>
                </div>
            </div>
            <div class="top-right">
                <div class="header-menu">
                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle active" data-toggle="dropdown" aria-haspopup="true"
                            aria-expanded="false">Welcome Admin</a>
                        <div class="user-menu dropdown-menu">
                            <a class="nav-link" href="#"><i class="fa fa-power-off"></i>Logout</a>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <?php echo $__env->yieldContent('dashboard'); ?>
        <?php echo $__env->yieldContent('product'); ?>
        <?php echo $__env->yieldContent('category'); ?>
        <?php echo $__env->yieldContent('admin'); ?>
        <div class="clearfix"></div>
        <footer class="site-footer">
            <div class="footer-inner bg-white">
                <div class="row">
                    <div class="col-sm-6">
                        Copyright &copy; Matchless@D
                    </div>
                    <div class="col-sm-6 text-right">
                        Designed by <a href="https://colorlib.com/">Colorlib</a>
                    </div>
                </div>
            </div>
        </footer>
    </div>
    <script src="<?php echo e(asset('public/assets/js/main.js')); ?>" ></script>
    <script src="<?php echo e(asset('public/assets/js/plugins.js')); ?>" ></script>
    <script src="<?php echo e(asset('public/assets/js/popper.min.js')); ?>" ></script>
    <script src="<?php echo e(asset('public/assets/js/widgets.js')); ?>" ></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\laravel\three\resources\views/admin/master.blade.php ENDPATH**/ ?>