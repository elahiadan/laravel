<!-- including master.balde.php file -->





<?php $__env->startSection('contact'); ?>

<div class="form-container" id="headingtext6">
        <h1 id="contactform">here! You can wish me too</h1>

        <form action="contactform" class="mainform filecontact" method="POST">
        <?php echo csrf_field(); ?>
            <div class="form" >
                <div class="form-1">
                    Name :<input type="text" name="name" placeholder="" id="form-name" class="plc" >
                </div>
                <div class="form-1">
                    Massage : <textarea name="message" id="massage" class="plc" cols="30" rows="5" ></textarea>
                </div class="form-1">
                <input type="submit" value="Send" class="btn" id="btn">
                <div>

                </div>
            </div>
        </form>
        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\final\resources\views/admin/contact.blade.php ENDPATH**/ ?>