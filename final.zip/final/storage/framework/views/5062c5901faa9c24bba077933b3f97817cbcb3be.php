

<?php $__env->startSection('product'); ?>

<div class="content pb-0">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header"><strong>Add Product</strong><small> Form</small></div>
                    <div class="card-body card-block">

                        <form action="submit_category" method="POST">
                        <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="company" class=" form-control-label">Category Name</label>
                                <input type="text" name="title" id="company" placeholder="Title" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="company" class=" form-control-label">Description</label>
                                <input type="text" name="description" id="company" placeholder="Description" class="form-control">
                            </div>
                            
                            <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
                                <span id="payment-button-amount">Submit</span>
                            </button>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\three\resources\views/admin/addcategory.blade.php ENDPATH**/ ?>