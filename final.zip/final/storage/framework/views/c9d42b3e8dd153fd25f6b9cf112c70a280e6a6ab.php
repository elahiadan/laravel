<!-- including master.balde.php file -->





<?php $__env->startSection('html'); ?>
<h1 style="text-align:center; margin-bottom:50px; margin-top:50px; color:red">Student Form</h1>



<div class="form-control1 container-form">
    <h2>Create Account</h2>
    <form action="subnewform" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <input type="hidden" name="id" value="">
        </div>
        <div class="form-group">
            Name<input type="text" name="name" id="plc1" placeholder="Please Enter Your Nmae" required>
        </div>
        <div class="form-group">
            Class<input type="text" name="class" placeholder="Please Enter Your Class" required>
        </div>
        <div class="form-group">
            Roll No.<input type="text" name="roll" placeholder="Please Enter Your Roll No." required>
        </div>
        <input type="submit" class="btn-form" value="Submit">
    </form>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\final\resources\views/admin/adddetails.blade.php ENDPATH**/ ?>