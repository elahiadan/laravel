


<?php $__env->startSection('admin'); ?>


<div class="content pb-0">
    <div class="orders">
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="box-title">Users List</h4>
                    </div>
                    <div class="card-body--">
                        <div class="table-stats order-table ov-h">
                            <table class="table ">
                                <thead>
                                    <tr>
                                        <th class="serial">ID</th>
                                        <th class="avatar">Avatar</th>
                                        <th>Email</th>
                                        <th>Total Product</th>
                                        <th>Role</th>
                                        <th>Edit</th>
                                        <th>Delete</th>
                                        <th>Status</th>

                                    </tr>
                                </thead>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tbody>
                                    <tr>
                                        <td class="serial"><?php echo e($cate->id); ?></td>
                                        <td class="avatar">
                                            <div class="round-img">
                                                <a href="#"><img class="rounded-circle" src="images/avatar/1.jpg"
                                                        alt=""></a>
                                            </div>
                                        </td>
                                        <td> <span class="name"><?php echo e($cate->email); ?></span> </td>
                                        <td><?php echo e($cate->role->tot_product); ?></td>
                                        <td> <span class="product"><?php echo e($cate->role->name); ?></span> </td>
                                        <td><span class="count"><a href="">Edit</a></span></td>
                                        <td><span class="count"><a href="">Delete</a></span></td>
                                        <td>
                                            <span class="badge badge-complete"><?php echo e($cate->created_at); ?></span>
                                        </td>
                                    </tr>
                                </tbody>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="assets/js/vendor/jquery-2.1.4.min.js" type="text/javascript"></script>
<script src="assets/js/popper.min.js" type="text/javascript"></script>
<script src="assets/js/plugins.js" type="text/javascript"></script>
<script src="assets/js/main.js" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\three\resources\views/admin/adminuser.blade.php ENDPATH**/ ?>