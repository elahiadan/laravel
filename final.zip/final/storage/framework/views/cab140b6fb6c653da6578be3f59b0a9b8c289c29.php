<!-- including master.balde.php file -->

<link rel="stylesheet" href="css/font-awesome.css">


<?php $__env->startSection('list'); ?>



<table>
    <thead>
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Class</th>
            <th>Roll No.</th>
            <th>Edit</th>
            <th>Delete</th>
            
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item->id); ?></td>
            <td><?php echo e($item->sname); ?></td>
            <td><?php echo e($item->sclass); ?></td>
            <td><?php echo e($item->sroll); ?></td>
            <td><a href="edit/<?php echo e($item->id); ?>">Edit</a></td>
            <td><a href="delete/<?php echo e($item->id); ?>"> <i class="fa-fa-trash"></i> Delete</a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\final\resources\views/admin/list.blade.php ENDPATH**/ ?>